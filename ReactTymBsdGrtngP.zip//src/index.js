var React = require("react");
var ReactDOM = require("react-dom");

const d = new Date();
const hr = d.getHours();
let greet;
let colo;
if (hr >= 0 && hr <= 12) {
  greet = "Good Morning";
  colo = { color: "red" };
} else if (hr > 12 && hr <= 18) {
  greet = "Good Evening";
  colo = { color: "green" };
} else {
  greet = "Good Night";
  colo = { color: "blue" };
}

ReactDOM.render(
  <h1 className="h" style={colo}>
    {greet}
  </h1>,
  document.getElementById("root")
);

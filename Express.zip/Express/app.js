const express =require("express");//exporting exprees module
const app=express();//made app of express
const port=80;//want to run our app on port 80


app.get("/",(req,res)=>{
    res.send("This is jack's first Home page using express app");
});//want to handle get reqst at / endpoint

// app.get("/",(req,res)=>{
//     res.status(200).send("This is jack's first Home page using express app");
// });want to handle get reqst at / endpoint


app.get("/about",(req,res)=>{
    res.send("This is jack's first About page usng express app");
});

app.post("/about",(req,res)=>{
    res.send("This is jack's post request first About page usng express app");
});

app.get("/this",(req,res)=>{
    res.status(404).send("This page is not found");
});

app.listen(port,()=>{
    console.log(`Application started successsfully on port ${port}`);
})
//importing function from mod.js
// const average=require("./mod");
// console.log(average([3,4]));
// console.log("This is index.js");
const mod=require("./mod");
// console.log(mod.avg([24,4]));
console.log(mod.name);
console.log("This is index.js");
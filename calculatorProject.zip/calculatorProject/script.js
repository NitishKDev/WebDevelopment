let b2='';
document.querySelector("#b1").addEventListener("click",function(){
    document.querySelector("p").innerHTML ='';
});

document.querySelector("#b2").addEventListener("click",function(){
    b2=document.querySelector("#b2").textContent;
    document.querySelector("p").innerHTML = document.querySelector("p").innerHTML + b2;
});

document.querySelector("#b3").addEventListener("click",function(){
    b2=document.querySelector("#b3").textContent;
    document.querySelector("p").innerHTML = document.querySelector("p").innerHTML + b2;
});

document.querySelector("#b4").addEventListener("click",function(){
    b2=document.querySelector("#b4").textContent;
    document.querySelector("p").innerHTML = document.querySelector("p").innerHTML + b2;
});

document.querySelector("#b5").addEventListener("click",function(){
    b2=document.querySelector("#b5").textContent;
    document.querySelector("p").innerHTML = document.querySelector("p").innerHTML + b2;
});

document.querySelector("#b6").addEventListener("click",function(){
    b2=document.querySelector("#b6").textContent;
    document.querySelector("p").innerHTML = document.querySelector("p").innerHTML + b2;
});

document.querySelector("#b7").addEventListener("click",function(){
    b2=document.querySelector("#b7").textContent;
    let res = document.querySelector("p").innerHTML;
    let out = (eval(res));
    document.querySelector("p").innerHTML = document.querySelector("p").innerHTML + ' = '+out;
});

document.querySelector("#b8").addEventListener("click",function(){
    b2=document.querySelector("#b8").textContent;
    document.querySelector("p").innerHTML = document.querySelector("p").innerHTML + b2;
});

document.querySelector("#b9").addEventListener("click",function(){
    b2=document.querySelector("#b9").textContent;
    document.querySelector("p").innerHTML = document.querySelector("p").innerHTML + b2;
});

document.querySelector("#b10").addEventListener("click",function(){
    b2=document.querySelector("#b10").textContent;
    document.querySelector("p").innerHTML = document.querySelector("p").innerHTML + b2;
});

document.querySelector("#b11").addEventListener("click",function(){
    b2=document.querySelector("#b11").textContent;
    document.querySelector("p").innerHTML = document.querySelector("p").innerHTML + b2;
});

document.querySelector("#b12").addEventListener("click",function(){
    b2=document.querySelector("#b12").textContent;
    document.querySelector("p").innerHTML = document.querySelector("p").innerHTML + b2;
});

document.querySelector("#b13").addEventListener("click",function(){
    b2=document.querySelector("#b13").textContent;
    document.querySelector("p").innerHTML = document.querySelector("p").innerHTML + b2;
});

document.querySelector("#b14").addEventListener("click",function(){
    b2=document.querySelector("#b14").textContent;
    document.querySelector("p").innerHTML = document.querySelector("p").innerHTML + b2;
});

document.querySelector("#b15").addEventListener("click",function(){
    b2=document.querySelector("#b15").textContent;
    document.querySelector("p").innerHTML = document.querySelector("p").innerHTML + b2;
});

document.querySelector("#b16").addEventListener("click",function(){
    b2=document.querySelector("#b16").textContent;
    document.querySelector("p").innerHTML = document.querySelector("p").innerHTML + b2;
});

document.querySelector("#b17").addEventListener("click",function(){
    b2=document.querySelector("#b17").textContent;
    document.querySelector("p").innerHTML = document.querySelector("p").innerHTML + b2;
});


